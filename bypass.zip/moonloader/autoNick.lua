local inicfg = require 'inicfg'
local arr = inicfg.load({ main = { nick = 'Ivan_Ivanov' } }, 'autoNick')
if not doesFileExist('moonloader/config/autoNick.ini') then inicfg.save(arr, 'autoNick.ini') end

function main()
	while not isSampAvailable() do wait(0) end
    if select(1, sampGetCurrentServerAddress()) == '95.181.158.32' and select(2, sampGetCurrentServerAddress()) == 7777 then
        sampSetLocalPlayerName(arr.main.nick)
    end
end