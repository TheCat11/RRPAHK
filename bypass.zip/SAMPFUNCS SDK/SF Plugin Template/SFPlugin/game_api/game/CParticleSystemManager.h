/*****************************************************************************
*
*  PROJECT:     Multi Theft Auto v1.0
*  LICENSE:     See LICENSE in the top level directory
*  FILE:        sdk/game/CParticleSystemManager.h
*  PURPOSE:     Particle system manager interface
*
*  Multi Theft Auto is available from http://www.multitheftauto.com/
*
*****************************************************************************/

#ifndef __CGAME_PARTICLESYSTEMMANAGER
#define __CGAME_PARTICLESYSTEMMANAGER

class CParticleSystemManager
{

};

#endif
