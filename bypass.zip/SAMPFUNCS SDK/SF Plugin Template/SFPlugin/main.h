#pragma once

#include "SAMPFUNCS_API.h"
#include "game_api.h"

extern SAMPFUNCS *SF;
